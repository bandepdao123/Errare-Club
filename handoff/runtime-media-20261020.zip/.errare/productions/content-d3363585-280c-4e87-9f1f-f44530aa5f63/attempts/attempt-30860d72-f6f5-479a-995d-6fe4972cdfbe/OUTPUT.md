Draft only, QA failed.
Master: C:\Errare-Club\media\productions\content-d3363585-280c-4e87-9f1f-f44530aa5f63\attempt-30860d72-f6f5-479a-995d-6fe4972cdfbe\master-v1.png
Provisional export: C:\Errare-Club\media\productions\content-d3363585-280c-4e87-9f1f-f44530aa5f63\attempt-30860d72-f6f5-479a-995d-6fe4972cdfbe\instagram-feed-draft-v1.jpg

The slow burn took 300 pages. My ice cream didn’t make it.

#ErrareClub #StillHuman #RomanceReader #BookClub
