Master: media/productions/content-497f129e-616e-479b-a374-af9bcd91779e/attempt-6941a556-b8b4-48b0-87b7-1d44852a5b16/bff-n01-master-v1.png
1080 square JPEG: media/productions/content-497f129e-616e-479b-a374-af9bcd91779e/attempt-6941a556-b8b4-48b0-87b7-1d44852a5b16/bff-n01-square-1080-v1.jpg

Booked the table. Sent the address. Somehow I’m still the only one here.

#ErrareClub #ThePlannerFriend #GroupChat #FriendGroup

Creative draft: official target profile unverified. Exact seat count not certified.
