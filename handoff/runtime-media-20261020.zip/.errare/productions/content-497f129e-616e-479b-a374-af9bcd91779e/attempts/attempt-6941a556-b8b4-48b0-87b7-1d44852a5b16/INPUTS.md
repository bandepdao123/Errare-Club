Product BFF-N01 snapshot 20261020T072032Z. Actual input: media/products/BFF-N01/a03d7df2db0bf8e9c96a1126f3da7ad3d742971dbb2bd6152dcee057ab4ffa22.jpg
SHA-256: a03d7df2db0bf8e9c96a1126f3da7ad3d742971dbb2bd6152dcee057ab4ffa22
Opened and hash-verified before generation. No cast or scene reference supplied.
